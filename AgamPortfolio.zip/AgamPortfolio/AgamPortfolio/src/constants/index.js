import {
  mobile,
  backend,
  creator,
  web,
  javascript,
  typescript,
  html,
  css,
  reactjs,
  redux,
  tailwind,
  nodejs,
  mongodb,
  git,
  figma,
  manage,
  docker,
  bornfire,
  exponance,
  roorkee,
  tripguide,
  threejs,
  swarnia,
  aicollege,
  ayurvedic,
  zomato,
  Windy,
  SWIB,
} from "../assets";



export const navLinks = [
  {
    id: "about",
    title: "About",
  },
  {
    id: "work",
    title: "Work",
  },
  {
    id: "contact",
    title: "Contact",
  },
];

const services = [
  {
    title: "AI & Learning Systems",
    icon: backend,
  },
  {
    title: "Web Developer",
    icon: web,
  },
  {
    title: "App Developer",
    icon: mobile,
  },
  {
    title: "MERN Stack Developer",
    icon: backend,
  },
  {
    title: "Business Consultant",
    icon: creator,
  },
  {
    title: "Web and Mobile Designs",
    icon: mobile,
  },
  {
    title: "Wordpress, Flutterflow, Webflow",
    icon: web,
  },

  {
    title: "Digital Marketing",
    icon: creator,
  },
  
];

const technologies = [
  {
    name: "HTML 5",
    icon: html,
  },
  {
    name: "CSS 3",
    icon: css,
  },
  {
    name: "JavaScript",
    icon: javascript,
  },
  {
    name: "TypeScript",
    icon: typescript,
  },
  {
    name: "React JS",
    icon: reactjs,
  },
  {
    name: "Redux Toolkit",
    icon: redux,
  },
  {
    name: "Tailwind CSS",
    icon: tailwind,
  },
  {
    name: "Node JS",
    icon: nodejs,
  },
  {
    name: "MongoDB",
    icon: mongodb,
  },
  {
    name: "Three JS",
    icon: threejs,
  },
  {
    name: "git",
    icon: git,
  },
  {
    name: "figma",
    icon: figma,
  },
  {
    name: "docker",
    icon: docker,
  },
];

const experiences = [
  {
    title: "Software Engineer",
    company_name: "Bornfire",
    icon: bornfire,
    iconBg: "#ffffff",
    date: "June 2024 - Present",
    points: [
      "Ideated and launched two tech-driven products (BRB and GIG) to expand local market presence and attract new funding opportunities, contributing to a projected company growth of up to 600 percent over the next five years.",
      "Designed and developed internal systems using Figma and React Native, including a hierarchy management system and a task and lead tracking tool, resulting in improved operational efficiency and enhanced team accountability.",
      "Designed and currently leading the development of the Bornfire client application to enhance customer trust, streamline communication, and improve overall service experience.",
      "Built the company’s complete digital presence, including branding, website assets, and cost-effective marketing strategies, while establishing a structured hiring process to support scalable business growth.",
    ],
  },
  {
    title: "Full Stack Developer",
    company_name: "Exponance",
    icon: exponance,
    iconBg: "#000000",
    date: "Sept 2022 - May 2024",
    points: [
      "Designed websites, application layouts, and user interfaces for individual clients and businesses. Also contributed as a product development consultant, supporting ideation, strategic planning, and marketing execution.",
      "Led digital marketing and social media strategies across multiple companies to increase online visibility, drive customer engagement, and support business growth for core brands and their subsidiaries.",
     
    ],
  },
  {
    title: "Research Intern",
    company_name: "IIT - Roorkee",
    icon: roorkee,
    iconBg: "#ffffff",
    date: "June 2022 - July 2023",
    points: [
      "Contributed to an advanced machine learning project in collaboration with a skilled team. Worked on algorithm development and implementation from conceptualization to deployment.",
     
    ],
  },
 
];

const testimonials = [
  {
    testimonial:
      "He has strong expertise in developing a business from all angles like technical, financial, and strategic. With a solid grasp of sales and marketing, he knows how to strengthen a business and drive growth. A true all-rounder, he brings everything needed to take any venture forward.",
    name: "Manish Bhushan Prasad",
    designation: "Director",
    company: "Bornfire",
    image: bornfire,
  },
  {
    testimonial:
      "We worked together on many projects, and it was truly a delight to witness his sharp thinking and aggressive problem-solving attitude. It’s always a great experience to learn from him and work alongside him.",
    name: "Ishan Sharma",
    designation: "Designer",
    company: "Lepide",
    image: "https://randomuser.me/api/portraits/men/5.jpg",
  },
  {
    testimonial:
      "We developed websites and applications together, and he has proven to be both a great developer and a brilliant strategist. Always a visionary, it’s a delight to see the clarity and creativity in his approach.",
    name: "Yogesh Vashisht",
    designation: "Developer",
    company: "Self",
    image: "https://randomuser.me/api/portraits/women/6.jpg",
  },
];

const projects = [
  {
    name: "AI College Helper",
    description:
      "AI College Help is a mobile application, currently published on the Play Store, designed to help students learn faster and smarter. The app allows users to upload PDFs or capture images of study material, and it instantly generates summaries, key points, quizzes, and instant solutions using AI.",
    tags: [
      // {
      //   name: "react",
      //   color: "blue-text-gradient",
      // },
      // {
      //   name: "mongodb",
      //   color: "green-text-gradient",
      // },
      // {
      //   name: "tailwind",
      //   color: "pink-text-gradient",
      // },
    ],
    image: aicollege,
    source_code_link: "https://github.com/aagamr/AI-College-Helper",
  },
  {
    name: "Swib",
    description:
      "Swib is a platform for makers and indie creators to showcase projects, gain feedback, and attract early users. Inspired by Product Hunt, it highlights even small MVPs and quickly gained strong traction, including early acquisition interest from a growing tech community.",
    tags: [
      {
        name: "Next.js",
        color: "blue-text-gradient",
      },
      {
        name: "MongoDB",
        color: "green-text-gradient",
      },
      {
        name: "Google Auth",
        color: "pink-text-gradient",
      },
    ],
    image: SWIB,
    source_code_link: "https://github.com/aagamr/Swib",
  },
  {
    name: "Windyui X gemini",
    description:
      "Windy UI x Gemini is a smart tool built for developers and designers to quickly generate and reuse modern UI components. With just a prompt, users can instantly generate clean, responsive UI elements, or simply browse and copy ready-made components to speed up their workflow.",
    tags: [
      {
        name: "Vite",
        color: "blue-text-gradient",
      },
      // {
      //   name: "supabase",
      //   color: "green-text-gradient",
      // },
      {
        name: "css",
        color: "pink-text-gradient",
      },
    ],
    image: Windy,
    source_code_link: "https://github.com/aagamr/Windy-X-Gemini",
  },
];

const designs = [
  {
    name: "Swarnia",
    description:
      " A clean, modern user interface focused on digital gold transactions with seamless user navigation. Designed with a luxury aesthetic to enhance trust and usability.",
    tags: [
      
      {
        name: "figma",
        color: "pink-text-gradient",
      },
    ],
    image: swarnia,
    source_code_link: "https://github.com/aagamr/Swarnia",
  },
  {
    name: "CollegeManagement",
    description:
      "An educational portal interface crafted for college faculty use. Prioritizes functionality with easy access to schedules, student data, and resources.",
    tags: [
     
      {
        name: "figma",
        color: "pink-text-gradient",
      },
    ],
    image: manage,
    source_code_link: "https://github.com/aagamr/College-Manage-College-Teacher-Page-",
  },
  {
    name: "Zomato Clone",
    description:
      "A food delivery app clone capturing the core experience of browsing, ordering, and tracking food. Built with a clean UI and UX similar to Zomato's design system.",
    tags: [
      
      {
        name: "figma",
        color: "pink-text-gradient",
      },
    ],
    image: zomato,
    source_code_link: "https://github.com/aagamr/Zomato-App-Clone",
  },

  
];





const upcoming = [
   
  
  
      
  
];



export { services, technologies, experiences, testimonials, projects, designs, upcoming };
